//
//  Eject_IntelApp.swift
//  Eject_Intel
//
//  Created by Shylock Wolf on 2025/12/15.
//

import SwiftUI

@main
struct Eject_IntelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
