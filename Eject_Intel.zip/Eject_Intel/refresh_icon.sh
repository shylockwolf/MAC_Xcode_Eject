#!/bin/bash

# 图标刷新脚本
echo "正在刷新 Eject_Intel 应用图标..."

# 清理项目缓存
echo "1. 清理项目缓存..."
rm -rf ~/Library/Developer/Xcode/DerivedData/*Eject_Intel* 2>/dev/null || true
rm -rf ./Eject_Intel.xcodeproj/project.xcworkspace/xcuserdata 2>/dev/null || true

# 重置图标权限
echo "2. 重置图标文件权限..."
chmod 644 Eject_Intel/Assets.xcassets/AppIcon.appiconset/*.png
chmod 644 Eject_Intel/Assets.xcassets/AppIcon.appiconset/Contents.json

# 触碰文件以更新时间戳
echo "3. 更新资源文件时间戳..."
touch Eject_Intel/Assets.xcassets/AppIcon.appiconset/Contents.json
touch Eject_Intel/Assets.xcassets/Contents.json

echo "完成！请在 Xcode 中："
echo "1. 关闭项目"
echo "2. 重新打开项目"
echo "3. 执行 Product -> Clean Build Folder"
echo "4. 重新构建并运行"
echo ""
echo "如果仍然显示空白，请检查："
echo "- Build Settings 中 ASSETCATALOG_COMPILER_APPICON_NAME 是否设置为 AppIcon"
echo "- General 选项卡中的 App Icons 设置是否正确"